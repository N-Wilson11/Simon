# avans-simon

(In Dutch)

cool project

deze keer doe ik 'm alleen, dus alles staat nu hier (met documentatie enzo)

## todo

- [x] software
- [x] hardware (+schema's)
- [x] software ontwerp (activiteitsdiagram)
- [x] blokschema, functiebeschrijving, en spelverloop
- [x] urenrapportage
