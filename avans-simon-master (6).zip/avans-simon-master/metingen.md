# led's

met protek 506 multimeter

|kleur|forward voltage|
|-|-|
|rood|2.18|
|geel|2.13|
|groen|2.27|
|blauw|2.91|

## berekeningen van de weerstanden

met $R=U/I$

arduino's digitale out geeft 20mA aan stroom met 3.3 V spanning

|kleur|weerstand|
|-|-|
|rood|56|
|geel|58|
|groen|51|
|blauw|19|

(gemeten; dit klopt)




